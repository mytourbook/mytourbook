/*******************************************************************************
 * Copyright (c) 2008 Stefan M�cke and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Stefan M�cke - initial API and implementation
 *******************************************************************************/
package org.eclipse.pde.nls.internal.ui.dialogs;

public class FilterOptions {

	public boolean filterPlugins; 
	public String[] pluginPatterns; 
	public boolean keysWithMissingEntriesOnly; 

}
